<?php
// This folder contains the file system snapshot data gathered by this plugin
if (!defined('ABSPATH')) {  // Ensure running within WordPress
    exit;
}
